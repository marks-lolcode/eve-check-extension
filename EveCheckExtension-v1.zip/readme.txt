ReadMe:

This extension uses DKVC Pathfinder to open EVE Gatecamp Check for the High Sec Static to Jita.

It works by looking for "HS" and "Static" and retreives the first word of the system name.

Instillation Instructions:
1) Download the .zip file
2) Extract the .zip file somewhere on your computer
3) In Chrome, click on the Extensions button or select Extensions -> Manage Extensions from the kebab menu.
4) Make sure Developer Mode is turned on (toggle in upper right corner)
5) Click the button to "Load Unpacked"
6) Navigate to the folder where you extracted the files
7) Click Select Folder
8) The extension should be installed

To use the extension, open Pathfinder and click the logo for the extension.